THIS FILE CONNTAINS COPYWRITE MATERIAL. DO NOT POST, THIS IS ONLY FOR EDUCATNAL NEEDS.

a file path with one of these posable exentions will disable the mod:
".disabled",".break",".remove",".no",".none"

A folder with the name, audio, changes any unquie