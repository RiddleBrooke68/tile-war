This file simply is here to explain the open comands that you can ether input into the cmd or as apart of a bat file.
Ether use the files path if the bat isn't in the same file, or you can use this if its in the same file:
    "tile war.exe"

Run comands:

--mp_start_server
    This makes a server on startup.

--mp_name : (Client_name) = Host
    If not spesfiyed before start up, it will set your name as Host, but feel free to put this in and change this name.

--map_type = 1
    Sets the map type.

--music_type = 0
    If set, will set the what music will be avaliable